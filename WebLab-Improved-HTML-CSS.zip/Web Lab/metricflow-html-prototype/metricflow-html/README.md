# MetricFlow — HTML Prototype

MetricFlow is a multi-page, semantic HTML prototype for a fictional B2B business intelligence product.

## Pages
- `index.html` — Executive overview
- `reports/index.html` — Revenue and performance reports
- `customers/index.html` — Customer directory and customer form
- `transactions/index.html` — Transaction history
- `settings/index.html` — Business profile and preferences

## Run locally
Open `index.html` in a browser. No build tools or dependencies are required.

## Current limitations
This is an HTML-only prototype. It uses fictional sample data. Search/filter controls and forms demonstrate structure and accessibility but do not process data, authenticate users, or save changes. Dynamic behavior can be added with JavaScript, visual styling with CSS, and persistent data/authentication with a backend.

## Product-quality details
- HTML5 document structure and language metadata
- Responsive viewport metadata
- Semantic landmarks and headings
- Accessible form labels and fieldsets
- Table captions and scoped headers
- Skip link and current-page navigation indicators
- Fictional `.example` email addresses

# Web Lab

A showcase website for business-focused web application concepts.

## Included concepts
- MetricFlow — Business Intelligence
- StockPilot — Inventory & Supply Chain
- TalentBridge — Recruitment & Applicant Tracking
- SprintDesk — Project & Team Management
- ResolveHQ — Customer Support & Helpdesk
- Ledgerly — Financial & Expense Management

## Run locally
Open `index.html` in a browser, or use the VS Code Live Server extension.

## Technologies
- HTML5
- CSS3
- Responsive layout
- Google Fonts (Manrope and DM Sans)

The project cards are showcase entries; links currently navigate to the relevant concept descriptions within this page. Replace them with live application URLs when those projects are deployed.
